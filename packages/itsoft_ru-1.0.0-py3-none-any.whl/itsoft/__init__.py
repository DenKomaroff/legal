from .itsoft_ru import ItSoftRu

__all__ = ["ItSoftRu"]
__version__ = "2025.07.11"
